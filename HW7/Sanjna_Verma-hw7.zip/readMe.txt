readMe.txt 

Sanjna Verma 
Last CS Assignment! 
Search for distance

***DISCLAIMER DID NOT DO EXTRA CREDIT***

The files used in this program are: 
ArrayStack
BinaryHeap
BoundedStackInterface
StackInterface
StackOverflowException
StackUnderflowException
Tree
TreeNode
UnboundedStackInterface
UnderflowException


Actively coded: 
Tree
TreeNode
BinaryHeap


TreeNode is a modification of a node class that has a comparesTo method, 
setRight/setLeft child method, etc
The Tree class is the class with the main running method. 

** IT PROMPTS THE USER TO ENTER AN INPUT **
When run, with this input for example: 

a 0 ( b 4 ( * 100 b 6 ) w 9 ( x 3 y 5 ( * 2 z 3 ) ) ) 


outputs with distance 16. 
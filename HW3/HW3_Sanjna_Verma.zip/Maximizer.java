//package llHomework;

public interface Maximizer<T> {
	T getMax(T t1, T t2);
	T getGlobalMin();
}
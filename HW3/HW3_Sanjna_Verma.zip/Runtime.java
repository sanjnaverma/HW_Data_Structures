//Implement to equalLists() function. 
//Analyze the running time of equalLists()

//There is a static function in LLHomeworkFunctions called equalLists. 
//Currently, it compared the two lists by calling "list1 == list2". 
//We know that's incorrect because it's only comparing the addresses of the 
//lists, and not the contents. We want two lists with equal contents to be 
//equal.

public class Runtime {

}

readME.txt

Sanjna Verma HW6 submission

used poem.txt to test the assignment. (args[0])

All methods are explained in the HuffmanConverter.java 